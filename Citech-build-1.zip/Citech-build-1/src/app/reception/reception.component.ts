import { Component, OnInit } from '@angular/core';
import { DRSRCServicesService } from '../Services/dr-sr-c-services.service';
import { PatientInformation, registration } from './Models/Models';
import {DialogModule} from 'primeng/dialog';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, FormsModule } from '@angular/forms';
import { ConfirmationService, ConfirmEventType, MessageService} from 'primeng/api';

@Component({
  selector: 'app-reception',
  templateUrl: './reception.component.html',
  styleUrls: ['./reception.component.css'],
  providers: [ConfirmationService,MessageService]
})

export class ReceptionComponent implements OnInit {

  constructor(private service: DRSRCServicesService,private router: Router,private confirmationService: ConfirmationService,private messageService: MessageService) { }

  users: PatientInformation[];

  registrationList : registration
  position: string;

  registration = {
   PatientName: '',
   Age: '',
   Gender: '',
   MobileNumber: '',
   Address: '',
  }

  displayBasic: boolean;
  editdisplay :boolean;

  ngOnInit(): void {
    this.registrationList = new registration();
    this.service.getReceptionInfo().subscribe(data =>{
      this.users = data;
      console.table(data);
    })
  }


  showAddDialog() {
    this.displayBasic = true;
  }


  showEditDialog(id) {
    this.editdisplay = true;
    this.service.getRegistered(id).subscribe(data => {
        console.table(data);
        this.registrationList = data;
      }
    )
    console.log(this.registrationList.patientName)
  }

  onSubmit() {
      const data ={
      PatientName: this.registration.PatientName,
      Age: this.registration.Age,
      Gender: this.registration.Gender,
      MobileNumber: this.registration.MobileNumber,
      Address: this.registration.Address,
     }
    this.service.addNewRegisration(data).subscribe(response =>{
      this.displayBasic = false;
      this.messageService.add({severity:'success', summary: 'New Record is Created successully', detail: 'new record created'});
      this.loadTable();
    }),
    error=>{
      console.log(error);
    };
  }

  onEditSubmit(){
    const data = {
      PatientID:this.registrationList.patientID,
      PatientName: this.registrationList.patientName,
      Age: this.registrationList.age,
      Gender: this.registrationList.gender,
      MobileNumber: this.registrationList.mobileNumber,
      Address: this.registrationList.address
    }
    this.service.updateRegisration(this.registrationList.patientID,data).subscribe(response =>{
      this.editdisplay = false;
      this.messageService.add({severity:'info', summary: 'Record is updated successully', detail: 'record updated'});
      this.loadTable();
    }),
    error=>{
      console.log(error);
    };
  }


  confirm2(id) {
    console.log("delete customer " + id);
  }

  deleteCustomer(id) {
    debugger;
    this.confirmationService.confirm({
        message: 'Do you want to delete this record?',
        header: 'Delete Confirmation',
        icon: 'pi pi-info-circle',
        accept: () => {
          this.service.deletePatientInfo(id).subscribe(data => console.log(data))
          this.loadTable();
          this.messageService.add({severity:'info', summary:'Confirmed', detail:'Record deleted'});
          this.loadTable();
        },
        reject: (type) => {
            switch(type) {
                case ConfirmEventType.REJECT:
                    this.messageService.add({severity:'error', summary:'Rejected', detail:'You have rejected'});
                break;
                case ConfirmEventType.CANCEL:
                    this.messageService.add({severity:'warn', summary:'Cancelled', detail:'You have cancelled'});
                break;
            }
        }
    });
  }

  loadTable(){
    this.service.getReceptionInfo().subscribe(data =>{
      this.users = data;
    })
  }

}

