export class PatientInformation{
  PatientID: number;
  PatientName: string;
  Age: number;
  Gender: string;
  MobileNumber: string;
  Address: string;
}

export class registration{
  patientID: number;
  patientName:string;
  age:number;
  gender:string;
  mobileNumber: string;
  address: string;
}
