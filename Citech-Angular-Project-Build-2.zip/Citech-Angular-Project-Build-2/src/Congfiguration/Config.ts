export const ApiConfig ={

  PatientApiConfig:{
    PatientInformation:`PatientInformation/GetPatientInformation`,
    NewPatientRegistration:`PatientInformation/AddPatientInformation`,
    UpdatePatientRegistration:`PatientInformation/UpdatePatientInformation`,
    DeletePatientInformation:`PatientInformation/DeletePatientInfo`
  },

  DepartmentApiConfig :{
    getDepartmentInfo:`Department/GetDepartment`,
    postDepartmentInfo:`Department/AddDepartment`,
  }
}
