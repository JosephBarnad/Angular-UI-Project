import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';

@Component({
  selector: 'app-patient-assignment',
  templateUrl: './patient-assignment.component.html',
  styleUrls: ['./patient-assignment.component.css']
})
export class PatientAssignmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
