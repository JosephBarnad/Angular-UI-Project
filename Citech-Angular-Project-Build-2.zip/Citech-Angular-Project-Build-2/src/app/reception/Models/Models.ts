export class PatientInformation{
  PatientID: number;
  PatientName: string;
  Age: number;
  Gender: string;
  MobileNumber: string;
  Address: string;
}

export class registration{
  patientID: number;
  patientName:string;
  age:number;
  gender:string;
  mobileNumber: string;
  address: string;
}

export class PatientAssignment{
  patientID:number;
  patientName: string;
  age:number;
  dateOfAssignment1 : Date;
  dateOfAssignment2: Date;
  clientNumber: string;
  Informant: string;
  Supervisor: string;
  Clinician: string;
}
