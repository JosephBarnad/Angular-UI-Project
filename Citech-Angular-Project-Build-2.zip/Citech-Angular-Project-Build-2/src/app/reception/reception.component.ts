import { Component, OnInit } from '@angular/core';
import { DRSRCServicesService } from '../Services/dr-sr-c-services.service';
import { PatientAssignment, PatientInformation, registration } from './Models/Models';
import {DialogModule} from 'primeng/dialog';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, FormsModule } from '@angular/forms';
import { ConfirmationService, ConfirmEventType, MessageService} from 'primeng/api';
import { NgxSpinnerService } from 'ngx-spinner';
import { CalendarModule } from 'primeng/calendar';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatDialog } from '@angular/material/dialog';
import { PatientAssignmentComponent } from './patient-assignment/patient-assignment.component';


@Component({
  selector: 'app-reception',
  templateUrl: './reception.component.html',
  styleUrls: ['./reception.component.css'],
  providers: [ConfirmationService,MessageService]
})

export class ReceptionComponent implements OnInit {

  constructor(public dialog: MatDialog,private service: DRSRCServicesService,private router: Router,private confirmationService: ConfirmationService,private messageService: MessageService,private SpinnerService: NgxSpinnerService) { }

  users: PatientInformation[];

  registrationList : registration;

  patientAssignment: PatientAssignment;

  position: string;

  registration = {
   PatientName: '',
   Age: '',
   Gender: '',
   MobileNumber: '',
   Address: '',
  }

  addDisplay: boolean;
  editdisplay :boolean;
  assignDisplay: boolean;
  value: Date;
  rangeDates: Date[];
  startDate = new Date(2000, 0, 2);

  ngOnInit(): void {
    this.registrationList = new registration();
    this.patientAssignment = new PatientAssignment()
    this.SpinnerService.show();
    this.service.getReceptionInfo().subscribe(data =>{
      this.users = data;
      console.table(data);
      setTimeout(() => {
        /** spinner ends after 5 seconds */
        this.SpinnerService.hide();
      }, 5000);
    })
  }


  showAddDialog() {
    this.addDisplay = true;
  }


  showEditDialog(id) {
    this.editdisplay = true;
    this.service.getRegistered(id).subscribe(data => {
        console.table(data);
        this.registrationList = data;
      }
    )
    console.log(this.registrationList.patientName)
  }

  showAssignmentDialog(id,name,age){
    this.assignDisplay=true;
    this.service.getRegistered(id).subscribe(data => {
      console.table(data);
      this.patientAssignment = data;
    }
  )
    console.log("Patient Id" + id);
    console.log("Patient Name" +name)
    console.log("Patient Age" +age)
  }

  onSubmit() {
      const data ={
      PatientName: this.registration.PatientName,
      Age: this.registration.Age,
      Gender: this.registration.Gender,
      MobileNumber: this.registration.MobileNumber,
      Address: this.registration.Address,
     }
    this.service.addNewRegisration(data).subscribe(response =>{
      this.addDisplay = false;
      this.messageService.add({severity:'success', summary: 'New Record is Created successully', detail: 'new record created'});
      this.loadTable();
    }),
    error=>{
      alert('API Service is not running! Kindly contact your admin')
      console.log(error);
    };
  }

  onEditSubmit(){
    const data = {
      PatientID:this.registrationList.patientID,
      PatientName: this.registrationList.patientName,
      Age: this.registrationList.age,
      Gender: this.registrationList.gender,
      MobileNumber: this.registrationList.mobileNumber,
      Address: this.registrationList.address
    }
    this.service.updateRegisration(this.registrationList.patientID,data).subscribe(response =>{
      this.editdisplay = false;
      this.messageService.add({severity:'info', summary: 'Record is updated successully', detail: 'record updated'});
      this.loadTable();
    }),
    error=>{
      console.log(error);
    };
  }


  confirm2(id,name) {
    console.log("Patient Id" + id);
    console.log("Patient Name" +name)
  }

  deleteCustomer(id) {
    debugger;
    this.confirmationService.confirm({
        message: 'Do you want to delete this record?',
        header: 'Delete Confirmation',
        icon: 'pi pi-info-circle',
        accept: () => {
          this.service.deletePatientInfo(id).subscribe(data => console.log(data))
          this.loadTable();
          this.messageService.add({severity:'info', summary:'Confirmed', detail:'Record deleted'});
          this.loadTable();
        },
        reject: (type) => {
            switch(type) {
                case ConfirmEventType.REJECT:
                    this.messageService.add({severity:'error', summary:'Rejected', detail:'You have rejected'});
                break;
                case ConfirmEventType.CANCEL:
                    this.messageService.add({severity:'warn', summary:'Cancelled', detail:'You have cancelled'});
                break;
            }
        }
    });
  }

  loadTable(){
    this.service.getReceptionInfo().subscribe(data =>{
      this.users = data;
    })
  }

  openDialog() {
    const dialogRef = this.dialog.open(PatientAssignmentComponent);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

}
