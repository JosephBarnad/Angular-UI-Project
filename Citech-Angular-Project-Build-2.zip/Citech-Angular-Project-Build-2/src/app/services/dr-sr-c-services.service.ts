import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ApiConfig } from 'src/Congfiguration/Config';
import { environment } from 'src/environments/environment';

//const baseURL = 'https://localhost:44303/Department/GetDepartment';

@Injectable({
  providedIn: 'root'
})
export class DRSRCServicesService {

  private apiRootUrl = environment.ApiRootUrl;
  private patientApiConfig = ApiConfig.PatientApiConfig;
  private departmentApiConfig = ApiConfig.DepartmentApiConfig;

  constructor(private http: HttpClient) { }

  getDepartmentInfo(): Observable<any> {
    return this.http.get(`${this.apiRootUrl}${this.departmentApiConfig.getDepartmentInfo}`)
  }

  addDepartmentInfo(data): Observable<any> {
    return this.http.post(`${this.apiRootUrl}${this.departmentApiConfig.postDepartmentInfo}`,data)
  }

  getReceptionInfo(): Observable<any> {
    return this.http.get(`${this.apiRootUrl}${this.patientApiConfig.PatientInformation}`).pipe(
      catchError((err)=>{
        console.log('error caught in service')
        alert('WEB API SERVICE NOT AVAILABLE! PLEASE CONTACT YOUR ADMINSTRATOR')
        return throwError(err);
      })
    )
  }

  addNewRegisration(data): Observable<any>{
    return this.http.post(`${this.apiRootUrl}${this.patientApiConfig.NewPatientRegistration}`,data)
  }

  getRegistered(id): Observable<any> {
    return this.http.get(`${this.apiRootUrl}${this.patientApiConfig.PatientInformation}/${id}`);
  }

  updateRegisration(id,data):Observable<any>{
    return this.http.put(`${this.apiRootUrl}${this.patientApiConfig.UpdatePatientRegistration}/${id}`,data)
  }

  deletePatientInfo(id):Observable<any>{
    return this.http.delete(`${this.apiRootUrl}${this.patientApiConfig.DeletePatientInformation}/${id}`)
  }

}
