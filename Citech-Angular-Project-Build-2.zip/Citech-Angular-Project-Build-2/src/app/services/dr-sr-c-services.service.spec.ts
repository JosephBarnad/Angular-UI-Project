import { TestBed } from '@angular/core/testing';

import { DRSRCServicesService } from './dr-sr-c-services.service';

describe('DRSRCServicesService', () => {
  let service: DRSRCServicesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DRSRCServicesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
