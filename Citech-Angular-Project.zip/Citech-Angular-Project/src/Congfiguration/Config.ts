export const ApiConfig ={

  PatientApiConfig:{
    PatientInformation:``
  },

  DepartmentApiConfig :{
    getDepartmentInfo:`Department/GetDepartment`,
    postDepartmentInfo:`Department/AddDepartment`,
  }
}
