import { Component, OnInit } from '@angular/core';
import { DRSRCServicesService } from '../Services/dr-sr-c-services.service';


@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  DepartmentInfo : any;

  constructor(private service: DRSRCServicesService) { }

  ngOnInit(): void {
    this.getDepartment()
  }

  getDepartment(): void {
    this.service.getDepartmentInfo().subscribe(response =>{
      this.DepartmentInfo = response;
      console.log(response);
    },error => {
      console.log(error);
    });
  }

  // getAllDepartmentInfo() : void {
  //   this.service.GetDepatmentList().subscribe(data =>{
  //     this.DepartmentInfo = data;
  //     console.log(data);
  //   })
  // }
}
