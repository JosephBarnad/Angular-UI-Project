import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiConfig } from 'src/Congfiguration/Config';
import { environment } from 'src/environments/environment';

//const baseURL = 'https://localhost:44303/Department/GetDepartment';

@Injectable({
  providedIn: 'root'
})
export class DRSRCServicesService {

  private apiRootUrl = environment.ApiRootUrl;
  private patientApiConfig = ApiConfig.PatientApiConfig;
  private departmentApiConfig = ApiConfig.DepartmentApiConfig;

  constructor(private http: HttpClient) { }

  getDepartmentInfo(): Observable<any> {
    return this.http.get(`${this.apiRootUrl}${this.departmentApiConfig.getDepartmentInfo}`)
  }

  addDepartmentInfo(data): Observable<any> {
    return this.http.post(`${this.apiRootUrl}${this.departmentApiConfig.postDepartmentInfo}`,data)
  }

  // GetDepatmentList(): Observable<any> {
  //   return this.http.get(baseURL);
  // }
}
